#!/sbin/sh

#rm -r -f /data/misc/riru/modules/edxposed/
#rm -r -f /data/misc/riru/modules/edxp/

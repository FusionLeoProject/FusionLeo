#!/sbin/sh

bp="/system/build.prop"

sed -i "/ro.build.display.id/d" $bp
echo "ro.build.display.id=LeoROM［Donate］V9.0" >> $bp

sed -i "/ro.build.leo/d" $bp
echo "ro.build.leo=JXU2Nzk3JXU1NjA5JXU1MDI5JTIwJXU2MjExJXU1NTlDJXU2QjIyJXU0RjYwJXU1MDVBJXU2MjExJXU1OTczJXU2NzBCJXU1M0NCJXU1OTdEJXU0RTBEJXU1OTdELiV1NjIxMSV1NjBGMyV1NEUwMCV1NzZGNCV1NUI4OCV1NjJBNCV1NTcyOCV1NEY2MCV1NzY4NCV1OEVBQiV1OEZCOQ==" >> $bp

echo "ro.build.leo.code=Leo Code(Android Pie)_v6.0" >> $bp
echo "ro.leo.ota.code=Qualcomm_S9" >> $bp
chmod 0644 $bp

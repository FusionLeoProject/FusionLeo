#!/sbin/sh

bp="/system/build.prop"

sed -i "/ro.build.leo/d" $bp
echo "ro.build.leo=bGVvcm9tNC4wJXU2NUIwJXU1RTc0JXU3MjQ4JXU2NzJDJTBB" >> $bp
echo "ro.build.leo.code=Leo Code(Android Pie)_v1.0" >> $bp
echo "ro.build.rom.name=Leo ROM" >> $bp
chmod 0644 $bp

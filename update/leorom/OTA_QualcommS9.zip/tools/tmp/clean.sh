#!/sbin/sh
/sbin/mount -a



rm -rf /system/priv-app/SecSetings
rm -rf /data/app/com.leo.salt*
rm -rf /data/data/com.leo.salt*

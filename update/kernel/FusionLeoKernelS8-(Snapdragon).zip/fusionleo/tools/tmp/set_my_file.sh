#!/sbin/sh
 
mount -o rw,remount /system
mount -o rw,remount /vendor
mount -o rw,remount /product

rm -f /tmp/BLmodel

BL=$(getprop ro.boot.bootloader)
BL=$(echo ${BL:0:5})  

echo "BL=$BL" >> /tmp/BLmodel





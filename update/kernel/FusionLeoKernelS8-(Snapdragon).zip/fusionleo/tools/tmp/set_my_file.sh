#!/sbin/sh
 
rm -f /tmp/BLmodel

BL=$(getprop ro.boot.bootloader)
BL=$(echo ${BL:0:5})  

echo "BL=$BL" >> /tmp/BLmodel





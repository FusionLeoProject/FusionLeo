#!/sbin/sh
/sbin/mount -a


rm -rf /system/app/MagiskManager
rm -rf /system/app/Magisk
rm -rf /system/priv-app/MagiskManager
rm -rf /system/priv-app/Magisk
rm -rf /data/app/*magisk*
rm -rf /data/data/*magisk*
rm -rf /data/app/com.topjohnwu.magisk*
rm -rf /data/data/com.topjohnwu.magisk*
rm -rf /data/adb/magisk*
rm -rf /data/adb/magisk/*
rm -rf /sbin/magisk*
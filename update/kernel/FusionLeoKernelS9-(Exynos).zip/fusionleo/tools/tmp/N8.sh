#!/sbin/sh
/sbin/mount -a


rm -rf /system/vendor/app/mcRegistry/ffffffffd0000000000000000000000a.tlbin
rm -rf /system/priv-app/Rlc
rm -rf /system/app/SecurityLogAgent
rm -rf /system/lib/libsecure_storage.so
rm -rf /system/lib64/libsecure_storage.so
rm -rf /system/vendor/lib/libsecure_storage.so
rm -rf /system/vendor/lib64/libsecure_storage.so
rm -rf /system/vendor/firmware/fimc_is_lib.bin
rm -rf /system/vendor/firmware/fimc_is_rta_2l2_3h1.bin




